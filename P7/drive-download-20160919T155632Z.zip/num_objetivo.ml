type oper = Sum | Res | Prod | Div;;

type expr = 
  Cte of int
| Oper of oper * expr * expr;;

let string_of_oper = function
    Sum -> "+"
  | Res -> "-"
  | Prod -> "*"
  | Div -> "/";;

let rec string_of_expr = function
    Cte a -> (string_of_int a)
  | Oper (a, b, c) -> "(" ^ (string_of_expr b) ^
    (string_of_oper a) ^ (string_of_expr c) ^ ")";;

let rec eval_expr = function
   Cte a -> if (a <= 0) then raise(Invalid_argument "eval_expr") else a
 | Oper (a, b, c) -> match a with
	Sum -> (sumar (eval_expr b) (eval_expr c))
	| Res -> if ((eval_expr b) - (eval_expr c)) < 0 
                    then raise (Invalid_argument "eval_expr")
	         else ((eval_expr b) - (eval_expr c))
	| Prod -> (producto (eval_expr b) (eval_expr c))
	| Div -> if ((eval_expr b) mod (eval_expr c)) != 0 
		    then raise (Invalid_argument "eval_expr")
		 else ((eval_expr b) / (eval_expr c));;

let rec lint_of_expr = function
    Cte a -> [a]
  | Oper (_, a, b) -> (lint_of_expr a)@(lint_of_expr b);;

let remove v l = 
    let rec aux l1 = function
	[] -> List.rev l1
      | h::t -> if v=h then (List.rev_append l1 t) else aux (h::l1) t
    in aux [] l;;

let rec r1 la lb = match la, lb with
    [], [] -> true
  | [], _ -> false
  | _, [] -> true
  | ha::ta, lb -> 
	if (List.mem ha lb) then r1 ta (remove ha lb)
	else r1 ta lb;;

let rec r2 = function
	[] -> true
      | h::t -> if (h <= 0) then false
		else r2 t;;

let rec res lint expr = 
    if (r1 lint (lint_of_expr expr)) && (r2 lint) then true
    else if not (r2 lint) 
         then raise (Invalid_argument "es_solucion")
    else false;;

let es_solucion nobj loper exp =
	if (nobj <= 0) then raise (Invalid_argument "es_solucion")
	else if ((eval_expr exp) = nobj) && (res loper exp) 
	   then true
	else false;;

let es_solucion nobj loper exp =
    try es_solucion nobj loper exp with
    Invalid_argument "eval_expr" -> raise (Invalid_argument "es_solucion");;
