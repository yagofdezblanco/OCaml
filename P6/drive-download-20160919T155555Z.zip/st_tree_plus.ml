open St_tree;;

let is_single arb =
    try let _ = ramas arb in false
    with Ramas -> true;;

let izq arb =
    let (i,_) = ramas arb in i;;

let dch arb =
    let (_,d) = ramas arb in d;; 

let rec size arb =
    if is_single arb then 1 
    else 1 + size (izq arb) + size (dch arb);; 

let rec height arb =
    if is_single arb then 0
    else 1 + max (height (izq arb)) (height (dch arb));;

let rec preorder arb =
    if is_single arb then [raiz arb]
    else let (i,d) = ramas arb in
      (raiz arb)::(preorder i)@(preorder d);;

let rec postorder arb =
    if is_single arb then [raiz arb]
    else let (i,d) = ramas arb in
      (postorder i)@(postorder d)@[raiz arb];;

let rec inorder arb =
    if is_single arb then [raiz arb]
    else let (i,d) = ramas arb in
      (inorder i)@[raiz arb]@(inorder d);;

let rec leafs arb =
    if is_single arb then [raiz arb]
    else (leafs (izq arb)) @ (leafs (dch arb));; 

let rec mirror arb =
    if is_single arb then arb
    else comp (raiz arb) (mirror (dch arb), mirror (izq arb));; 
 
let rec treemap f arb =
    if is_single arb then single (f (raiz arb))
    else comp (f (raiz arb)) (treemap f (izq arb), treemap f (dch arb));; 



