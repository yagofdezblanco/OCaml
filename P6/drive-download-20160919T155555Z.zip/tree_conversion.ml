open St_tree;;
open St_tree_plus;;
open Bin_tree;;

let rec bin_tree_of_st_tree st =
   if St_tree_plus.is_single st then Node (St_tree.raiz st, Empty, Empty)
   else
      let (sr1, sr2) = St_tree.ramas st in
         Node (St_tree.raiz st, bin_tree_of_st_tree sr1, bin_tree_of_st_tree sr2);; 

let rec st_tree_of_bin_tree bt = match bt with
    Empty -> raise (Invalid_argument "st_tree_of_bin_tree")
    | Node (raiz, Empty, Empty) -> St_tree.single raiz
    | Node (raiz, Empty, _) -> raise (Invalid_argument "st_tree_of_bin_tree")
    | Node (raiz, br1, br2) -> St_tree.comp raiz (st_tree_of_bin_tree br1, st_tree_of_bin_tree br2);; 
