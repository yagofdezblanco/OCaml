type 'a bin_tree =
    Empty
    | Node of 'a * 'a bin_tree * 'a bin_tree;;

exception Ramas;;

let empty = Empty;;

let comp r (i, d) = Node (r, i, d);;

let raiz = function
    Empty -> raise Ramas
    | Node (r, _, _) -> r;;

let ramas = function
    Node (_, i, d) -> (i,d)
    | _ -> raise Ramas;;

let is_empty arb =
    try let _ = ramas arb in false
    with Ramas -> true;;

let izq arb =
    let (i,_) = ramas arb in i;;

let dch arb =
    let (_,d) = ramas arb in d;; 

let rec size arb =
    if is_empty arb then 0 
    else 1 + size (izq arb) + size (dch arb);; 

let rec height arb =
    if is_empty arb then 0
    else 1 + max (height (izq arb)) (height (dch arb));;

let rec preorder arb =
    if is_empty arb then []
    else let (i,d) = ramas arb in
        (raiz arb)::(preorder i)@(preorder d);;

let rec postorder arb =
    if is_empty arb then []
    else let (i,d) = ramas arb in
        (postorder i)@(postorder d)@[raiz arb];;

let rec inorder arb =
    if is_empty arb then []
    else let (i,d) = ramas arb in
        (inorder i)@[raiz arb]@(inorder d);;

let rec leafs = function
    Empty -> []
    | Node(arb, Empty, Empty) -> [arb]
    | Node (_,i,d) -> (leafs i)@(leafs d);;

let rec mirror arb =
    if is_empty arb then arb
    else comp (raiz arb) (mirror (dch arb), mirror (izq arb));; 
 
let rec treemap f arb =
    if is_empty arb then Empty
    else comp (f (raiz arb)) (treemap f (izq arb), treemap f (dch arb));;


